
I downloaded the data for the project from Map Zen's pre-defined Raleigh, North Carolina metropolitan area.  (https://s3.amazonaws.com/metro-extracts.mapzen.com/raleigh_north-carolina.osm.bz2)
https://mapzen.com/data/metro-extracts

This area is known as the Triangle region because it includes the three major cities: Raleigh, Durham, Chapel Hill as well as three major research universities: North Carolina State University, Duke University, and University of Chapel Hill.  It is also home to research and technology hub, Research Triangle Park.

I chose this area because this is where I live and work and I thought that familiarity with the area would be helpful to the data cleaning process and would also help me better appreciate OpenStreetMap.

This project submission contains the following:

* "data wrangling project writeup.pdf" - the pdf document containing my responses to the rubric questions

* "Data Wrangling Project - Raleigh Map data.ipynb" - the python notebook containing the code that I used to audit and clean the dataset, including the code for the lesson 6 quizzes

* "data wrangling project references.txt" - the resources used in this project

* sample.osm - a sample of the OSM file used in this project

* raleigh_map.html - the code used to make a visualization of the Raleigh metropolitan area bounds
